(function () {
  'use strict';
  var routes = window.themeRoutes || {};
  var strings = window.themeStrings || {};
  var lastCartTrigger = null;
  var cartBusy = false;
  function getDrawer() { return document.getElementById('CartDrawer'); }
  function showError(form, message) {
    var target = form && form.querySelector('[data-form-error]');
    if (target) { target.textContent = message || strings.error; target.hidden = false; }
  }
  function openDrawer(trigger) {
    var drawer = getDrawer();
    if (!drawer || !drawer.showModal) { return false; }
    lastCartTrigger = trigger || document.activeElement;
    if (!drawer.open) { drawer.showModal(); }
    return true;
  }
  function refreshCart() {
    return fetch(routes.cart + '?section_id=cart-drawer', {credentials:'same-origin', headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function (response) {
      if (!response.ok) { throw new Error(strings.error); }
      return response.text();
    }).then(function (text) {
      var parsed = new DOMParser().parseFromString(text, 'text/html');
      var fresh = parsed.querySelector('[data-cart-drawer-content]');
      var current = document.querySelector('#CartDrawer [data-cart-drawer-content]');
      if (!fresh || !current) { throw new Error(strings.error); }
      current.replaceWith(fresh);
      document.querySelectorAll('[data-cart-count]').forEach(function (el) { el.textContent = fresh.dataset.itemCount; });
    });
  }
  function changeLine(key, quantity) {
    if (cartBusy) { return; }
    cartBusy = true;
    var drawer = getDrawer();
    if (drawer) { drawer.setAttribute('aria-busy','true'); }
    fetch(routes.cartChange,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({id:key,quantity:quantity})}).then(function(response){
      return response.json().then(function(payload){if(!response.ok){throw new Error(payload.description || payload.message || strings.error);} return payload;});
    }).then(refreshCart).catch(function(error){
      var target = document.querySelector('[data-cart-error]');
      if(target){target.textContent=error.message;target.hidden=false;}
    }).finally(function(){cartBusy=false;if(drawer){drawer.removeAttribute('aria-busy');}});
  }
  document.addEventListener('click',function(event){
    var trigger=event.target.closest('[data-cart-open]');
    if(trigger && getDrawer() && getDrawer().showModal){event.preventDefault();openDrawer(trigger);}
    var closer=event.target.closest('[data-cart-close]');
    if(closer && getDrawer()){getDrawer().close();}
    var remove=event.target.closest('[data-cart-remove]');
    if(remove && remove.closest('#CartDrawer')){event.preventDefault();changeLine(remove.dataset.lineKey,0);}
    var contact=event.target.closest('[data-expand-contact]');
    if(contact){var details=document.querySelector(contact.getAttribute('href'));if(details){details.open=true;}}
    var deleteAddress=event.target.closest('[data-delete-address]');
    if(deleteAddress && !window.confirm(strings.deleteAddress)){event.preventDefault();}
  });
  document.addEventListener('submit',function(event){
    var form=event.target;
    if(!form.matches('[data-ajax-product]') || !getDrawer() || !getDrawer().showModal || !window.fetch){return;}
    event.preventDefault();
    var button=event.submitter || form.querySelector('button[type="submit"]');
    var error=form.querySelector('[data-form-error]');
    if(error){error.hidden=true;}
    if(button){button.disabled=true;button.setAttribute('aria-busy','true');}
    var added=false;
    fetch(routes.cartAdd,{method:'POST',credentials:'same-origin',headers:{'Accept':'application/json'},body:new FormData(form)}).then(function(response){
      return response.json().then(function(payload){if(!response.ok){throw new Error(payload.description || payload.message || strings.error);}return payload;});
    }).then(function(){
      added=true;
      var status=document.getElementById('CartStatus');if(status){status.textContent=strings.added;}
      return refreshCart();
    }).then(function(){openDrawer(button);}).catch(function(error){
      if(added){window.location.assign(routes.cart);}else{showError(form,error.message);}
    }).finally(function(){if(button){button.disabled=button.dataset.available==='false';button.removeAttribute('aria-busy');}});
  });
  document.addEventListener('change',function(event){
    var quantity=event.target.closest('[data-cart-line-quantity]');
    if(quantity){
      var number=Number(quantity.value);
      if(Number.isInteger(number) && number>=0 && quantity.checkValidity()){changeLine(quantity.dataset.lineKey,number);}
      else{quantity.reportValidity();}
    }
    var select=event.target.closest('[data-variant-select]');
    if(select){
      var container=select.closest('[data-product-section]');
      var variants=JSON.parse(container.querySelector('[data-variant-json]').textContent);
      var variant=variants.find(function(item){return String(item.id)===select.value;});
      if(!variant){return;}
      var price=container.querySelector('[data-product-price]');price.textContent=variant.price;
      if(variant.compare){var compare=document.createElement('s');compare.textContent=variant.compare;price.appendChild(document.createTextNode(' '));price.appendChild(compare);}
      var unit=container.querySelector('[data-unit-price]');if(unit){unit.textContent=variant.unit||'';unit.hidden=!variant.unit;}
      var button=container.querySelector('[data-add-button]');button.disabled=!variant.available;button.dataset.available=String(variant.available);
      container.querySelector('[data-add-label]').textContent=variant.available?strings.add:strings.soldOut;
      var qty=container.querySelector('[name="quantity"]');qty.min=variant.min;qty.step=variant.step;if(variant.max!==null){qty.max=variant.max;}else{qty.removeAttribute('max');}if(!qty.checkValidity()){qty.value=variant.min;}
      var url=new URL(window.location.href);url.searchParams.set('variant',variant.id);window.history.replaceState({},'',url);
    }
    if(event.target.matches('[data-address-country]')){updateProvinces(event.target);}
  });
  document.addEventListener('keydown',function(event){
    if(event.key==='Escape'){document.querySelectorAll('.mobile-menu[open],.header-search[open],.nav-dropdown[open]').forEach(function(el){el.open=false;});}
  });
  function updateProvinces(select) {
    var form=select.closest('form');var province=form.querySelector('[data-address-province]');if(!province){return;}
    var option=select.selectedOptions[0];var list=[];
    try{list=JSON.parse(option.getAttribute('data-provinces') || '[]');}catch(error){list=[];}
    province.replaceChildren();
    list.forEach(function(pair){var item=document.createElement('option');item.value=pair[0];item.textContent=pair[1];province.appendChild(item);});
    province.closest('.field').hidden=list.length===0;
    if(province.dataset.default){province.value=province.dataset.default;}
  }
  function initialize(root){
    var drawer=getDrawer();if(drawer && !drawer.dataset.bound){
      drawer.dataset.bound='true';drawer.addEventListener('click',function(event){if(event.target===drawer){var bounds=drawer.getBoundingClientRect();if(event.clientX<bounds.left || event.clientX>bounds.right || event.clientY<bounds.top || event.clientY>bounds.bottom){drawer.close();}}});
      drawer.addEventListener('close',function(){if(lastCartTrigger && lastCartTrigger.isConnected){lastCartTrigger.focus();}});
    }
    (root || document).querySelectorAll('[data-address-country]').forEach(function(select){if(select.dataset.default){select.value=select.dataset.default;}updateProvinces(select);});
  }
  initialize(document);
  document.addEventListener('shopify:section:load',function(event){initialize(event.target);});
})();


(function(){
  'use strict';
  var origin=new WeakMap();
  document.addEventListener('click',function(event){
    var opener=event.target.closest('[data-info-open]');
    if(opener){
      var dialog=document.getElementById(opener.dataset.infoOpen);
      if(dialog && typeof dialog.showModal==='function'){
        event.preventDefault();origin.set(dialog,opener);
        if(!dialog.dataset.informationBound){
          dialog.dataset.informationBound='true';
          dialog.addEventListener('close',function(){var trigger=origin.get(dialog);if(trigger && trigger.isConnected){trigger.focus();}});
          dialog.addEventListener('click',function(e){if(e.target===dialog){var r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom){dialog.close();}}});
        }
        dialog.showModal();
      }
    }
    var closer=event.target.closest('[data-info-close]');
    if(closer){var parent=closer.closest('dialog');if(parent){parent.close();}}
    var contact=event.target.closest('[data-info-contact]');
    if(contact){
      var current=contact.closest('dialog');if(current){current.close();}
      var form=document.getElementById('FooterContact-'+contact.dataset.infoContact);if(form){form.open=true;}
    }
  });
})();

